package com.example.rrp.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

	@GetMapping("/login")
	public String loginForm() {
		return "login";
	}

	@PostMapping("/logincheck")
	public String postLogin(Authentication authentication) {
		if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_LECTURER"))) {
			return "redirect:/lecturer/createSession";
		} else {
			return "redirect:/student/dashboard";
		}
	}
}

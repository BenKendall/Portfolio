package com.example.academigymraeg.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.academigymraeg.model.Noun;
import com.example.academigymraeg.model.Question;
import com.example.academigymraeg.model.Result;
import com.example.academigymraeg.model.Test;
import com.example.academigymraeg.model.User;
import com.example.academigymraeg.repo.NounRepository;
import com.example.academigymraeg.repo.QuestionRepository;
import com.example.academigymraeg.repo.ResultRepository;
import com.example.academigymraeg.repo.TestRepository;

@Service
public class TestService {
    @Autowired
    private TestRepository testRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private NounRepository nounRepository;

    @Autowired
    private ResultRepository resultRepository;

    public List<Test> findAllTests() {
        return (List<Test>) testRepository.findAll();
    }

    public Optional<Test> findTestById(int testId) {
        return testRepository.findById(testId);
    }

    public Test generateTest() {
        List<Noun> nouns = StreamSupport.stream(nounRepository.findAll().spliterator(), false)
                                        .collect(Collectors.toList());
        Collections.shuffle(nouns);
        if (nouns.size() > 20) {
            nouns = nouns.subList(0, 20);
        }

        Test test = new Test();
        List<Question> questions = nouns.stream().map(noun -> {
            Question question = new Question();
            question.setNoun(noun);
            question.setTest(test);
            question.setQuestionType(getRandomQuestionType());
            return question;
        }).collect(Collectors.toList());

        test.setQuestions(questions);
        return testRepository.save(test);
    }

    private String getRandomQuestionType() {
        List<String> types = List.of("gender", "meaning", "translation");
        Collections.shuffle(types);
        return types.get(0);
    }

    public Result saveTestResult(Test test, User user, List<String> answers) {
        if (test == null || user == null) {
            throw new IllegalArgumentException("Test or User cannot be null");
        }

        Result result = new Result();
        result.setTest(test);
        result.setUser(user);
        result.setScore(calculateScore(test, answers));
        return resultRepository.save(result);
    }

    private int calculateScore(Test test, List<String> answers) {
        int score = 0;
        List<Question> questions = test.getQuestions();
        for (int i = 0; i < questions.size() && i < answers.size(); i++) {
            if (answers.get(i).equalsIgnoreCase(questions.get(i).getNoun().getWelsh())) {
                score++;
            }
        }
        return score;
    }
}
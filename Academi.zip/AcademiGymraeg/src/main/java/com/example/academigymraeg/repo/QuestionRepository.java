package com.example.academigymraeg.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.academigymraeg.model.Question;

public interface QuestionRepository extends CrudRepository<Question, Integer> {
	List<Question> findByTestId(int testId);
}

package com.example.academigymraeg.security;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.academigymraeg.model.Permission;
import com.example.academigymraeg.model.User;
import com.example.academigymraeg.repo.PermissionRepository;
import com.example.academigymraeg.repo.UserRepository;

import jakarta.annotation.PostConstruct;

@Component
public class FirstUserConfigurer {

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private PermissionRepository permRepo;

	@Autowired
	private UserRepository userRepo;

	@PostConstruct
	public void setup() {
		if (permRepo.countByRoleName("LECTURER") < 1)
			permRepo.save(new Permission("LECTURER"));
		if (permRepo.countByRoleName("STUDENT") < 1)
			permRepo.save(new Permission("STUDENT"));
		if (permRepo.countByRoleName("ADMIN") < 1)
			permRepo.save(new Permission("ADMIN"));

		if (userRepo.countByUsername("admin") < 2) {
			User admin = new User();
			admin.setUsername("student");
			admin.setPassword(passwordEncoder.encode("password"));
			List<Permission> adminPermissions = new LinkedList<>();
			adminPermissions.add(permRepo.findByRoleName("STUDENT"));
			admin.setPermissions(adminPermissions);

			userRepo.save(admin);
		}

	}

}

package com.example.academigymraeg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.academigymraeg.model.Permission;
import com.example.academigymraeg.model.User;
import com.example.academigymraeg.repo.PermissionRepository;
import com.example.academigymraeg.repo.UserRepository;

@Service
public class UserService {

	private final UserRepository userRepository;
	private final PermissionRepository permissionRepository;
	private final PasswordEncoder passwordEncoder;

	@Autowired
	public UserService(UserRepository userRepository, PermissionRepository permissionRepository,
			PasswordEncoder passwordEncoder) {
		this.userRepository = userRepository;
		this.permissionRepository = permissionRepository;
		this.passwordEncoder = passwordEncoder;
	}

	public User createUser(String username, String password, List<String> roleNames) {
		User user = new User();
		user.setUsername(username);
		user.setPassword(passwordEncoder.encode(password));
		List<Permission> permissions = new ArrayList<>();
		for (String roleName : roleNames) {
			Permission permission = permissionRepository.findByRoleName(roleName);
			if (permission != null) {
				permissions.add(permission);
			} else {
				throw new IllegalArgumentException("Role not found: " + roleName);
			}
		}
		user.setPermissions(permissions);
		return userRepository.save(user);
	}

	public List<User> findAllUsers() {
		return (List<User>) userRepository.findAll();
	}

	public void deleteUser(String username) {
		userRepository.deleteById(username);
	}

	public void resetUserPassword(String username, String newPassword) {
		User user = userRepository.findById(username)
				.orElseThrow(() -> new IllegalArgumentException("User not found with username: " + username));
		user.setPassword(passwordEncoder.encode(newPassword));
		userRepository.save(user);
	}

	public Optional<User> findUserByUsername(String username) {
		return userRepository.findById(username);
	}

	public User updateUserRoles(String username, List<String> newRoles) {
		User user = userRepository.findById(username)
				.orElseThrow(() -> new IllegalArgumentException("User not found with username: " + username));

		List<Permission> updatedPermissions = new ArrayList<>();
		for (String roleName : newRoles) {
			Permission permission = permissionRepository.findByRoleName(roleName);
			if (permission != null) {
				updatedPermissions.add(permission);
			} else {
				throw new IllegalArgumentException("Role not found: " + roleName);
			}
		}
		user.setPermissions(updatedPermissions);
		return userRepository.save(user);
	}
}

package com.example.academigymraeg.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.academigymraeg.model.Result;

public interface ResultRepository extends CrudRepository<Result, Integer> {
	List<Result> findByUserUsername(String username);

	List<Result> findByTestId(int testId);
}

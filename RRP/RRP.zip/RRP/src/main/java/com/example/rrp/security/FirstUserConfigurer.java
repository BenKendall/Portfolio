package com.example.rrp.security;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.rrp.model.Permission;
import com.example.rrp.model.User;
import com.example.rrp.repo.PermissionRepository;
import com.example.rrp.repo.UserRepository;

import jakarta.annotation.PostConstruct;

@Component
public class FirstUserConfigurer {

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private PermissionRepository permRepo;

	@Autowired
	private UserRepository userRepo;

	@PostConstruct
	public void setup() {
		if (permRepo.countByRoleName("LECTURER") < 1)
			permRepo.save(new Permission("LECTURER"));
		if (permRepo.countByRoleName("STUDENT") < 1)
			permRepo.save(new Permission("STUDENT"));
		if (userRepo.countByUsername("lecturer") < 1) {
			User u = new User();
			u.setUsername("lecturer");
			u.setPassword(passwordEncoder.encode("password"));
			List<Permission> p = new LinkedList<Permission>();
			p.add(permRepo.findByRoleName("LECTURER"));
			u.setPermissions(p);

			userRepo.save(u);
		}

	}

}

package com.example.academigymraeg.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.academigymraeg.model.User;

public interface UserRepository extends CrudRepository<User, String> {

	int countByUsername(String string);

}

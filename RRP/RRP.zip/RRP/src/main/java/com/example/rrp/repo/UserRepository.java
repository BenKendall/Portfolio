package com.example.rrp.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.rrp.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, String> {

	int countByUsername(String string);

	boolean existsByUsername(String username);

}

package com.example.academigymraeg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.academigymraeg.model.User;
import com.example.academigymraeg.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private UserService userService;

	@GetMapping("/users")
	public String listUsers(Model model) {
		model.addAttribute("users", userService.findAllUsers());
		return "admin/users";
	}

	@GetMapping("/users/create")
	public String showCreateUserForm(Model model) {
		model.addAttribute("user", new User());
		return "admin/create_user";
	}

	@PostMapping("/users")
	public String createUser(@ModelAttribute User user, @RequestParam List<String> roles) {
		userService.createUser(user.getUsername(), user.getPassword(), roles);
		return "redirect:/admin/users";
	}

	@GetMapping("/users/delete/{username}")
	public String deleteUser(@PathVariable String username) {
		userService.deleteUser(username);
		return "redirect:/admin/users";
	}

	@GetMapping("/users/reset/{username}")
	public String showResetPasswordForm(@PathVariable String username, Model model) {
		model.addAttribute("username", username);
		return "admin/reset_password";
	}

	@PostMapping("/users/reset/{username}")
	public String resetUserPassword(@PathVariable String username, @RequestParam String newPassword) {
		userService.resetUserPassword(username, newPassword);
		return "redirect:/admin/users";
	}
}
package com.example.academigymraeg.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.academigymraeg.model.Noun;
import com.example.academigymraeg.repo.NounRepository;

@Service
public class NounService {
	@Autowired
	private NounRepository nounRepository;

	public Noun createNoun(Noun noun) {
		return nounRepository.save(noun);
	}

	public List<Noun> getAllNouns() {
		Iterable<Noun> nouns = nounRepository.findAll();
		return StreamSupport.stream(nouns.spliterator(), false).collect(Collectors.toList());
	}

	public Optional<Noun> findNounById(int id) {
		return nounRepository.findById(id);
	}

	public Noun updateNoun(Noun noun) {
		return nounRepository.save(noun);
	}

	public void deleteNoun(int id) {
		nounRepository.deleteById(id);
	}
}

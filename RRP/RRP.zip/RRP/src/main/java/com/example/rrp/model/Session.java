package com.example.rrp.model;

import java.time.LocalDateTime;
import java.util.Random;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "session")
public class Session {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int sessionId;

	@Column(name = "active")
	private boolean active;

	@Column(name = "dynamic_code")
	private String dynamicCode;

	@Column(name = "module_code")
	private String moduleCode;

	@Column(name = "start_time")
	private LocalDateTime startTime;

	private int verificationDigit1Index;
	private int verificationDigit2Index;

	public void generateRandomDigitIndices(int libraryCardLength) {
		Random random = new Random();
		verificationDigit1Index = random.nextInt(libraryCardLength);
		verificationDigit2Index = random.nextInt(libraryCardLength);

		while (verificationDigit1Index == verificationDigit2Index) {
			verificationDigit2Index = random.nextInt(libraryCardLength);
		}
	}

	public int getSessionId() {
		return sessionId;
	}

	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public String getDynamicCode() {
		return dynamicCode;
	}

	public void setDynamicCode(String dynamicCode) {
		this.dynamicCode = dynamicCode;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getVerificationDigit1Index() {
		return verificationDigit1Index;
	}

	public void setVerificationDigit1Index(int verificationDigit1Index) {
		this.verificationDigit1Index = verificationDigit1Index;
	}

	public int getVerificationDigit2Index() {
		return verificationDigit2Index;
	}

	public void setVerificationDigit2Index(int verificationDigit2Index) {
		this.verificationDigit2Index = verificationDigit2Index;
	}
}

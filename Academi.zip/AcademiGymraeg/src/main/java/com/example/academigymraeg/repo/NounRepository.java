package com.example.academigymraeg.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.academigymraeg.model.Noun;

public interface NounRepository extends CrudRepository<Noun, Integer> {

}

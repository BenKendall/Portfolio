package com.example.rrp.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.rrp.model.Permission;

@Repository
public interface PermissionRepository extends CrudRepository<Permission, Integer> {

	int countByRoleName(String string);

	Permission findByRoleName(String string);

}

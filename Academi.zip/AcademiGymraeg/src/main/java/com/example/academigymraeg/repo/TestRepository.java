package com.example.academigymraeg.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.academigymraeg.model.Test;

public interface TestRepository extends CrudRepository<Test, Integer> {

}

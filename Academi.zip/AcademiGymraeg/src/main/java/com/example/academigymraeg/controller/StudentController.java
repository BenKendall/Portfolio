package com.example.academigymraeg.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.academigymraeg.model.Result;
import com.example.academigymraeg.model.Test;
import com.example.academigymraeg.model.User;
import com.example.academigymraeg.service.ResultService;
import com.example.academigymraeg.service.TestService;
import com.example.academigymraeg.service.UserService;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private TestService testService;

    @Autowired
    private UserService userService;
    
    @Autowired
    private ResultService resultService;

    @GetMapping("/tests")
    public String listAvailableTests(Model model) {
        List<Test> tests = testService.findAllTests();
        model.addAttribute("tests", tests);
        return "student/tests";
    }

    @GetMapping("/tests/take/{testId}")
    public String takeTest(@PathVariable int testId, Model model) {
        Optional<Test> test = testService.findTestById(testId);
        if (!test.isPresent()) {
            model.addAttribute("error", "Test not found.");
            return "error";
        }
        model.addAttribute("test", test.get());
        return "student/take_test";
    }

    @PostMapping("/tests/submit/{testId}")
    public String submitTest(@PathVariable int testId, @RequestParam List<String> answers, Principal principal,
                             RedirectAttributes redirectAttrs) {
        Optional<User> user = userService.findUserByUsername(principal.getName());
        Optional<Test> test = testService.findTestById(testId);
        
        if (!user.isPresent() || !test.isPresent()) {
            redirectAttrs.addFlashAttribute("error", "Failed to submit test due to missing user or test data.");
            return "redirect:/student/tests";
        }

        testService.saveTestResult(test.get(), user.get(), answers);
        redirectAttrs.addFlashAttribute("success", "Test submitted successfully.");
        return "redirect:/student/results";
    }

    @GetMapping("/results")
    public String viewResults(Model model, Principal principal) {
        List<Result> results = resultService.findResultsByUserId(principal.getName());
        model.addAttribute("results", results);
        return "student/results";
    }
}

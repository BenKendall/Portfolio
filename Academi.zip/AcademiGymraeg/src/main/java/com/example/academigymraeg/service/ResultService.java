package com.example.academigymraeg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.academigymraeg.model.Result;
import com.example.academigymraeg.repo.ResultRepository;

@Service
public class ResultService {
	@Autowired
	private ResultRepository resultRepository;

	public List<Result> findResultsByUserId(String userId) {
		return resultRepository.findByUserUsername(userId);
	}

	public Result saveResult(Result result) {
		return resultRepository.save(result);
	}

	public List<Result> findResultsByTestId(int testId) {
		return resultRepository.findByTestId(testId);
	}
}
package com.example.rrp.service;

public interface AttendanceService {
	boolean recordAttendance(String username, String moduleCode, String dynamicCode, int digit1, int digit2);
}

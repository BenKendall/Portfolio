package com.example.academigymraeg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.academigymraeg.model.Noun;
import com.example.academigymraeg.service.NounService;

@Controller
@RequestMapping("/lecturer")
public class LecturerController {

	@Autowired
	private NounService nounService;

	@GetMapping("/nouns")
	public String listNouns(Model model) {
		model.addAttribute("nouns", nounService.getAllNouns());
		return "lecturer/nouns";
	}

	@GetMapping("/nouns/create")
	public String showCreateNounForm(Model model) {
		model.addAttribute("noun", new Noun());
		return "lecturer/create_noun";
	}

	@PostMapping("/nouns")
	public String createNoun(@ModelAttribute Noun noun) {
		nounService.createNoun(noun);
		return "redirect:/lecturer/nouns";
	}

	@GetMapping("/nouns/edit/{id}")
	public String showEditNounForm(@PathVariable int id, Model model) {
		Noun noun = nounService.findNounById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalid noun Id:" + id));
		model.addAttribute("noun", noun);
		return "lecturer/edit_noun";
	}

	@PostMapping("/nouns/update/{id}")
	public String updateNoun(@PathVariable int id, @ModelAttribute Noun noun) {
		noun.setId(id);
		nounService.updateNoun(noun);
		return "redirect:/lecturer/nouns";
	}

	@GetMapping("/nouns/delete/{id}")
	public String deleteNoun(@PathVariable int id) {
		nounService.deleteNoun(id);
		return "redirect:/lecturer/nouns";
	}
}
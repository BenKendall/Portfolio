package com.example.rrp.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.rrp.model.Session;
import com.example.rrp.repo.SessionRepository;

@Service
public class SessionServiceImpl implements SessionService {

	@Autowired
	private SessionRepository sessionRepository;

	private final Random random = new Random();

	public Session createSession(String moduleCode, LocalDateTime startTime) {
		Session session = new Session();
		session.setModuleCode(moduleCode);
		session.setStartTime(startTime);
		session.setActive(true);
		session.setDynamicCode(generateDynamicCode());
		session.generateRandomDigitIndices(8);
		sessionRepository.save(session);
		return session;
	}

	public Session verifyCodeAndGetSession(String code) {
		Optional<Session> sessionOpt = sessionRepository.findActiveSessionByDynamicCode(code);
		return sessionOpt.orElse(null);
	}

	public void endSession(int sessionId) {
		sessionRepository.findById(sessionId).ifPresent(session -> {
			session.setActive(false);
			sessionRepository.save(session);
		});
	}

	public List<Session> getActiveSessionsOrdered() {
		return sessionRepository.findActiveSessionsOrderedByStartTime();
	}

	private String generateDynamicCode() {
		return String.valueOf(1000 + random.nextInt(9000));
	}

	public Session getCurrentSession() {
		return sessionRepository.findFirstByActiveTrueOrderByStartTimeDesc()
				.orElseThrow(() -> new RuntimeException("No active session found."));
	}

	@Scheduled(fixedRate = 30000)
	public void refreshSessionCodes() {
		getActiveSessionsOrdered().forEach(session -> {
			session.setDynamicCode(generateDynamicCode());
			sessionRepository.save(session);
		});
	}
}
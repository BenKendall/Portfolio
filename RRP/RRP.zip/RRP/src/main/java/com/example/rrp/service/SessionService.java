package com.example.rrp.service;

import java.time.LocalDateTime;
import java.util.List;

import com.example.rrp.model.Session;

public interface SessionService {
	Session createSession(String moduleCode, LocalDateTime startTime);

	Session verifyCodeAndGetSession(String code);

	void endSession(int sessionId);

	List<Session> getActiveSessionsOrdered();

	Session getCurrentSession();
}

package com.example.academigymraeg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiGymraegApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademiGymraegApplication.class, args);
	}

}

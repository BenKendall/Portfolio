function updateCode(sessionId) {
	fetch(`/lecturer/sessionCode/${sessionId}`)
		.then(response => response.text())
		.then(newCode => {
			document.getElementById('dynamicCode').textContent = newCode;
		})
		.catch(error => console.error('Error fetching new code:', error));
}

setInterval(() => updateCode(sessionId), 30000);
